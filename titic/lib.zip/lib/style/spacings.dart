const kHorizontalPaddingS = kHorizontalPadding / 2;
const kVerticalPaddingS = kVerticalPadding / 2;

const kHorizontalPadding = 18.0;
const kVerticalPadding = 18.0;

const kHorizontalPaddingL = kHorizontalPadding * 2;
const kVerticalPaddingL = kVerticalPadding * 2;

const kHorizontalPaddingXL = kHorizontalPaddingL * 2;
const kVerticalPaddingXL = kVerticalPaddingL * 2;
