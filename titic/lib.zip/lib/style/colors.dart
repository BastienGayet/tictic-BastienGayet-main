import 'dart:ui';

const kMainColor = Color.fromRGBO(52, 78, 65, 1);
const kSecondaryColor =  Color.fromRGBO(88, 129, 87, 1);
const kTertiaryColor =  Color.fromRGBO(163, 177, 138, 1);
const kBackgroundColor =   Color.fromRGBO(242, 239, 228, 1);
const kErrorColor =   Color.fromRGBO(238, 99, 82, 1);